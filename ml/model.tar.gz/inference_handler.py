import torch
import json
import os
from asta_gnn_model import AstaSafetyBrain

def model_fn(model_dir):
    """
    Loads the trained ST-GNN model from the model directory.
    """
    # Initialize the model architecture
    model = AstaSafetyBrain(node_features=3, hidden_dim=64, seq_len=1)

    # Load the state dictionary
    with open(os.path.join(model_dir, 'model.pth'), 'rb') as f:
        model.load_state_dict(torch.load(f))

    model.eval()
    return model

def input_fn(request_body, request_content_type):
    """
    Pre-processes the incoming JSON request into tensors.
    Expecting: { 'nodes': [[lighting, crime, crowd], ...], 'adj': [[...], ...] }
    """
    if request_content_type == 'application/json':
        data = json.loads(request_body)
        nodes = torch.tensor(data['nodes'], dtype=torch.float32).unsqueeze(0) # [Batch=1, Nodes, Features]
        adj = torch.tensor(data['adj'], dtype=torch.float32)
        return nodes, adj
    else:
        raise ValueError("Unsupported content type: " + request_content_type)

def predict_fn(input_data, model):
    """
    Performs inference using the loaded model.
    """
    nodes, adj = input_data
    with torch.no_grad():
        output = model(nodes, adj)
    return output

def output_fn(prediction, content_type):
    """
    Post-processes the model output into a JSON response.
    """
    # Prediction shape: [Batch=1, Nodes, 1]
    scores = prediction.squeeze().tolist()
    if not isinstance(scores, list):
        scores = [scores] # Handle single node case

    return json.dumps({
        "safety_scores": scores,
        "overall_score": sum(scores) / len(scores) if scores else 0
    })
